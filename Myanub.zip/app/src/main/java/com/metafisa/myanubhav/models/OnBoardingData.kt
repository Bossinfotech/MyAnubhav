package com.metafisa.myanubhav.models

import java.net.URL

class OnBoardingData ( var title: String, var desc: String, var imageURL: Int)