package com.metafisa.myanubhav

data class ItemsViewModel(val image: Int, val text: String) {
}